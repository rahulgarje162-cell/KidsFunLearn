# Kids Fun & Learn — Android MVP

A colorful educational game for children ages 2–5.

## Included
- 10 mini-games
- 100 total levels (10 per game)
- Numbers, ABC, Colors, Shapes, Animals, Matching, Picture Puzzle, Words, Easy Math, Find & Think
- Level unlocking and local star progress
- Parent area with progress, language selector, and reset
- Child-friendly large buttons and positive feedback
- Offline-first gameplay
- English/Hindi/Marathi language setting scaffold

## Build
Open this folder in Android Studio and build the `app` module. The project uses Kotlin + Jetpack Compose and Android API 35.

## Next production work
- Replace emoji with custom illustrations
- Add recorded child-friendly voice/audio
- Add real picture-puzzle drag/drop mechanics
- Add proper matching-card memory gameplay
- Add full localization strings and tested TTS per language
- Add privacy/parent consent flow before any analytics or online features
- QA on multiple Android screen sizes
## Free APK build with GitHub Actions

This project is configured to build the APK for free using GitHub Actions. It does not require Android Studio on your device.

1. Create a free GitHub repository.
2. Upload the contents of this project to the repository's `main` branch.
3. Open **Actions** → **Build Kids Fun & Learn APK**.
4. Choose **Run workflow** if it has not started automatically.
5. Open the completed workflow run.
6. Under **Artifacts**, download **KidsFunLearn-debug-apk**.
7. Extract it to get `app-debug.apk`.

The workflow installs JDK 17, Gradle 8.9, and Android SDK 35 on GitHub's runner and builds a debug APK.

Note: this is a test/debug APK. A Play Store release needs signing and store/privacy preparation.
