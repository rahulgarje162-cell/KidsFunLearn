package com.kidsfunlearn.app

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Bg = Color(0xFFF2FAFF)
private val Dark = Color(0xFF25324A)

data class Game(val title: String, val emoji: String, val color: Color, val description: String)
data class Question(val prompt: String, val visual: String, val options: List<String>, val answer: String, val hint: String)

data class Progress(val unlocked: Int, val stars: Int)

val games = listOf(
    Game("Numbers", "🔢", Color(0xFFFF6B6B), "Count and recognize 1–10"),
    Game("ABC", "🔤", Color(0xFF8E63E8), "Letters and simple sounds"),
    Game("Colors", "🎨", Color(0xFFFFB91E), "Learn everyday colors"),
    Game("Shapes", "🔷", Color(0xFF27B77A), "Circle, square and more"),
    Game("Animals", "🐶", Color(0xFF3E9FEF), "Friendly animal friends"),
    Game("Matching", "🧩", Color(0xFFE85B9E), "Find the same picture"),
    Game("Picture Puzzle", "🖼️", Color(0xFF10AAA4), "Complete simple pictures"),
    Game("Words", "📝", Color(0xFFFF7B25), "Picture and word matching"),
    Game("Easy Math", "➕", Color(0xFF9656D9), "Tiny addition and subtraction"),
    Game("Find & Think", "🧠", Color(0xFF3D88D9), "Patterns and simple logic")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KidsFunLearnApp(applicationContext) }
    }
}

@Composable
fun KidsFunLearnApp(context: Context) {
    var screen by remember { mutableStateOf("home") }
    var selectedGame by remember { mutableIntStateOf(0) }
    var selectedLevel by remember { mutableIntStateOf(1) }
    var stars by remember { mutableIntStateOf(context.getSharedPreferences("progress", 0).getInt("stars", 0)) }
    var unlocked by remember { mutableIntStateOf(context.getSharedPreferences("progress", 0).getInt("unlocked", 1)) }
    var showParents by remember { mutableStateOf(false) }
    var showLanguage by remember { mutableStateOf(false) }
    var language by remember { mutableStateOf(context.getSharedPreferences("settings", 0).getString("language", "English") ?: "English") }

    fun save() {
        context.getSharedPreferences("progress", 0).edit().putInt("stars", stars).putInt("unlocked", unlocked).apply()
    }

    if (showParents) {
        ParentScreen(stars, language, onLanguage = { showLanguage = true }, onReset = {
            stars = 0; unlocked = 1; save()
        }, onBack = { showParents = false })
        if (showLanguage) {
            LanguageDialog(language) { newLang -> language = newLang; context.getSharedPreferences("settings", 0).edit().putString("language", newLang).apply(); showLanguage = false }
        }
        return
    }

    when (screen) {
        "home" -> HomeScreen(stars, onGame = { selectedGame = it; screen = "levels" }, onParents = { showParents = true })
        "levels" -> LevelScreen(games[selectedGame], unlocked, onBack = { screen = "home" }, onLevel = { selectedLevel = it; screen = "play" })
        "play" -> GameScreen(games[selectedGame], selectedGame, selectedLevel, onBack = { screen = "levels" }, onHome = { screen = "home" }, onComplete = { earned ->
            stars += earned
            if (selectedLevel == unlocked && unlocked < 10) unlocked++
            save()
        }, onNext = { if (selectedLevel < 10) { selectedLevel++ } else screen = "levels" })
    }
}

@Composable
fun Header(title: String, stars: Int, onBack: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) Text("‹", fontSize = 42.sp, color = Dark, modifier = Modifier.clickable { onBack() }) else Spacer(Modifier.width(34.dp))
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Dark, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
        Text("⭐ $stars", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Dark)
    }
}

@Composable
fun HomeScreen(stars: Int, onGame: (Int) -> Unit, onParents: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg)) {
        Header("Kids Fun & Learn", stars)
        Text("🌈 Learn • Play • Smile 🌈", Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 17.sp, color = Dark)
        Spacer(Modifier.height(6.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(11.dp), horizontalArrangement = Arrangement.spacedBy(11.dp), modifier = Modifier.weight(1f)) {
            items(games.indices.toList()) { i ->
                val game = games[i]
                Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(game.color), modifier = Modifier.height(128.dp).clickable { onGame(i) }) {
                    Column(Modifier.fillMaxSize().padding(9.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Text(game.emoji, fontSize = 40.sp)
                        Text(game.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(game.description, color = Color.White, fontSize = 10.sp, textAlign = TextAlign.Center)
                    }
                }
            }
        }
        Text("👨‍👩‍👧 Parent Area", color = Dark, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth().clickable { onParents() }.padding(14.dp), textAlign = TextAlign.Center)
    }
}

@Composable
fun LevelScreen(game: Game, unlocked: Int, onBack: () -> Unit, onLevel: (Int) -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg)) {
        Header("${game.emoji} ${game.title}", 0, onBack)
        Text("Choose a level", Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 17.sp, color = Dark)
        LazyVerticalGrid(columns = GridCells.Fixed(2), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp), horizontalArrangement = Arrangement.spacedBy(13.dp)) {
            items((1..10).toList()) { level ->
                val locked = level > unlocked
                Button(onClick = { if (!locked) onLevel(level) }, enabled = !locked, modifier = Modifier.height(82.dp), shape = RoundedCornerShape(22.dp), colors = ButtonDefaults.buttonColors(containerColor = game.color, disabledContainerColor = Color(0xFFD9E0E8))) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (locked) "🔒 Level $level" else "Level $level", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(if (locked) "Complete previous" else "⭐⭐⭐", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun GameScreen(game: Game, gameIndex: Int, level: Int, onBack: () -> Unit, onHome: () -> Unit, onComplete: (Int) -> Unit, onNext: () -> Unit) {
    val question = remember(gameIndex, level) { makeQuestion(gameIndex, level) }
    var chosen by remember(gameIndex, level) { mutableStateOf<String?>(null) }
    var showHint by remember(gameIndex, level) { mutableStateOf(false) }
    var awarded by remember(gameIndex, level) { mutableStateOf(false) }
    val correct = chosen == question.answer

    LaunchedEffect(correct) { if (correct && !awarded) { awarded = true; onComplete(3) } }

    Column(Modifier.fillMaxSize().background(Bg), horizontalAlignment = Alignment.CenterHorizontally) {
        Header("Level $level", 0, onBack)
        Text("${game.emoji} ${game.title}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Dark)
        Spacer(Modifier.height(10.dp))
        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp), RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(Color.White)) {
            Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("🔊 ${question.prompt}", fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = Dark)
                Spacer(Modifier.height(12.dp))
                Text(question.visual, fontSize = 56.sp, textAlign = TextAlign.Center)
            }
        }
        Spacer(Modifier.height(16.dp))
        Column(Modifier.padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
            question.options.chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                    row.forEach { option ->
                        val c = when { chosen == option && option == question.answer -> Color(0xFF27B77A); chosen == option -> Color(0xFFFF7B7B); else -> game.color }
                        Button(onClick = { chosen = option }, modifier = Modifier.width(145.dp).height(66.dp), shape = RoundedCornerShape(20.dp), colors = ButtonDefaults.buttonColors(containerColor = c)) { Text(option, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }
        Spacer(Modifier.height(15.dp))
        when {
            chosen == null -> { OutlinedButton(onClick = { showHint = true }) { Text("💡 Hint") }; if (showHint) Text(question.hint, color = Dark, modifier = Modifier.padding(7.dp), textAlign = TextAlign.Center) }
            correct -> { Text("🎉 Wonderful!", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Color(0xFF16845A)); Text("⭐⭐⭐", fontSize = 24.sp); Button(onClick = onNext, modifier = Modifier.padding(top = 9.dp), shape = RoundedCornerShape(18.dp)) { Text(if (level < 10) "Next Level ➜" else "Back to Games") } }
            else -> { Text("🙂 Try again!", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Dark); Button(onClick = { chosen = null }) { Text("Try Again") } }
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceEvenly) { Text("🏠 Home", color = Dark, modifier = Modifier.clickable { onHome() }); Text("⭐ 3 stars", color = Dark) }
    }
}

@Composable
fun ParentScreen(stars: Int, language: String, onLanguage: () -> Unit, onReset: () -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg)) {
        Header("Parent Area", stars, onBack)
        Card(Modifier.fillMaxWidth().padding(16.dp), RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(Color.White)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("📊 Learning Progress", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Dark)
                Text("⭐ Total stars: $stars", fontSize = 18.sp, color = Dark)
                Text("🎮 10 learning games • 100 levels", fontSize = 17.sp, color = Dark)
                Text("🌐 Language: $language", fontSize = 17.sp, color = Dark)
                Button(onClick = onLanguage, modifier = Modifier.fillMaxWidth()) { Text("🌐 Change Language") }
                OutlinedButton(onClick = onReset, modifier = Modifier.fillMaxWidth()) { Text("🔄 Reset Progress") }
            }
        }
    }
}

@Composable
fun LanguageDialog(current: String, onSelect: (String) -> Unit) {
    AlertDialog(onDismissRequest = { onSelect(current) }, title = { Text("Choose Language") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { listOf("English", "हिन्दी", "मराठी").forEach { lang -> Text(lang, Modifier.fillMaxWidth().clickable { onSelect(lang) }.padding(14.dp), fontSize = 19.sp) } } }, confirmButton = {})
}

fun makeQuestion(game: Int, level: Int): Question {
    val n = level.coerceIn(1, 10)
    return when (game) {
        0 -> { val count = n; Question("How many apples?", "🍎 ".repeat(count).trim(), listOf("$count", "${(count % 10) + 1}", "${(count - 1).coerceAtLeast(1)}"), "$count", "Touch and count each apple.") }
        1 -> { val letters = listOf("A","B","C","D","E","F","G","H","I","J"); val pics = listOf("🍎","⚽","🐱","🐶","🥚","🐟","🍇","🏠","🍦","🧃"); val a=letters[n-1]; Question("Which letter is this?", "${pics[n-1]}\n$a", listOf(a, letters[n % 10], letters[(n+1)%10]), a, "Look at the big letter.") }
        2 -> { val names=listOf("RED","BLUE","GREEN","YELLOW","ORANGE","PURPLE","PINK","BROWN","BLACK","WHITE"); val em=listOf("🔴","🔵","🟢","🟡","🟠","🟣","🩷","🟤","⚫","⚪"); val a=names[n-1]; Question("What color is this?", em[n-1], listOf(a,names[n%10],names[(n+1)%10]),a,"Look at the color circle.") }
        3 -> { val names=listOf("CIRCLE","SQUARE","TRIANGLE","STAR","HEART","OVAL","DIAMOND","RECTANGLE","MOON","HEXAGON"); val em=listOf("⭕","🟦","🔺","⭐","❤️","🥚","🔶","▭","🌙","⬡"); val a=names[n-1]; Question("What shape is this?",em[n-1],listOf(a,names[n%10],names[(n+1)%10]),a,"Look at the outline.") }
        4 -> { val names=listOf("DOG","CAT","COW","LION","ELEPHANT","MONKEY","FISH","BIRD","RABBIT","TURTLE"); val em=listOf("🐶","🐱","🐮","🦁","🐘","🐒","🐟","🐦","🐰","🐢"); val a=names[n-1]; Question("Which animal is this?",em[n-1],listOf(a,names[n%10],names[(n+1)%10]),a,"Say the animal name.") }
        5 -> { val p=listOf("🍎","🐶","🚗","⭐","🐱","⚽","🍌","🦋","🌈","🐘"); val a=p[n-1]; Question("Find the same picture", "$a   ${p[n%10]}   $a", listOf(a,p[n%10],p[(n+1)%10]),a,"Choose the picture you see twice.") }
        6 -> { val p=listOf("🦁","🐘","🚗","🚀","🏠","🌳","🐟","🍎","🦋","🌈"); val a=p[n-1]; Question("Which picture completes it?", "${a} 🧩", listOf(a,p[n%10],p[(n+1)%10]),a,"Look for the missing picture.") }
        7 -> { val w=listOf("CAT","DOG","SUN","CAR","BALL","FISH","TREE","BOOK","CUP","BUS"); val p=listOf("🐱","🐶","☀️","🚗","⚽","🐟","🌳","📖","☕","🚌"); val a=w[n-1]; Question("Which word matches?",p[n-1],listOf(a,w[n%10],w[(n+1)%10]),a,"Say the picture name.") }
        8 -> { val b=(n%4)+1; val c=(n%3)+1; val sum=b+c; Question("How much is $b + $c?", "🍎 ".repeat(b)+" + "+" 🍎 ".repeat(c), listOf("$sum","${sum+1}","${sum-1}"),"$sum","Count all the apples together.") }
        else -> { val kind=n%3; val seq=when(kind){0->"🔴 🔵 🔴 🔵 ❓";1->"⭐ 🌙 ⭐ 🌙 ❓";else->"🍎 🍌 🍎 🍌 ❓"}; val a=when(kind){0->"🔴";1->"⭐";else->"🍎"}; Question("What comes next?",seq,listOf(a,"🐶","🟢"),a,"Look for the repeating pattern.") }
    }
}
